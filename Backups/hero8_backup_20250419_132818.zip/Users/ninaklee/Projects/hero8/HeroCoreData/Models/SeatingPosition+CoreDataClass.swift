//
//  SeatingPosition+CoreDataClass.swift
//  HeroCoreData
//
//  Created for hero8 on 18.04.2025.
//
//

import Foundation
import CoreData

@objc(SeatingPosition)
public class SeatingPosition: NSManagedObject {

}
