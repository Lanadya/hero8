//
//  Class+CoreDataClass.swift
//  HeroCoreData
//
//  Created for hero8 on 18.04.2025.
//
//

import Foundation
import CoreData

@objc(Class)
public class Class: NSManagedObject {

}
