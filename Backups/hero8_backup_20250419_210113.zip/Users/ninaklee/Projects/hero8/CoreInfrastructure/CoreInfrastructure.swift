//
//  CoreInfrastructure.swift
//  CoreInfrastructure
//
//  Created by Nina Klee on 19.04.25.
//

import Foundation

