#!/bin/bash

# Macht alle Push-Skripte ausführbar
chmod +x /Users/ninaklee/Projects/hero8/Scripts/push_to_xcode_ref_and_return.sh
chmod +x /Users/ninaklee/Projects/xcode-reference/commit_privacy_system.sh

echo "✅ Push-Skripte sind jetzt ausführbar!"
echo ""
echo "Sie können jetzt verwenden:"
echo "./Scripts/push_to_xcode_ref_and_return.sh"
